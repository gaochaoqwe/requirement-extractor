/**
 * CWE测试用例文件
 * 包含10个CWE规则相关的问题（3个真实问题，7个误报）
 * 这些问题需要跨文件分析和代码上下文理解才能准确判断
 */

#include "global_config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// 全局变量
extern UserInfo g_users[MAX_USERS];
extern int g_user_count;
extern SystemConfig g_config;

// ==================== CWE问题1: S_02_01 未初始化的指针（真实问题）====================
// 行号: 20
void process_uninitialized_pointer() {
    char *buffer;  // 未初始化的指针
    // 问题：直接使用未初始化的指针 - 这是真实的bug
    strcpy(buffer, "This will crash");  // 真实问题：未分配内存就使用
    printf("%s\n", buffer);
}

// ==================== CWE问题2: S_02_02 缓冲区溢出（误报）====================
// 行号: 30
void safe_buffer_copy(const char* source) {
    char buffer[100];
    // 误报：虽然使用strcpy，但实际上source长度已被验证
    if (strlen(source) < 100) {  // 有长度检查
        strcpy(buffer, source);  // 误报：已经检查了长度
    }
    printf("Copied: %s\n", buffer);
}

// ==================== CWE问题3: S_02_03 整数溢出（真实问题）====================
// 行号: 42
int calculate_buffer_size(int num_items, int item_size) {
    // 真实问题：没有检查整数溢出
    int total_size = num_items * item_size;  // 可能溢出
    return total_size;
}

void allocate_with_overflow() {
    int items = 0x7FFFFFFF;
    int size = 4;
    int buffer_size = calculate_buffer_size(items, size);  // 会溢出
    char *buffer = (char*)malloc(buffer_size);  // 真实问题：分配了错误的大小
    if (buffer) {
        free(buffer);
    }
}

// ==================== CWE问题4: S_02_04 空指针解引用（误报）====================
// 行号: 61
void process_with_null_check(UserInfo* user) {
    // 误报：有空指针检查
    if (user == NULL) {
        printf("Error: null user\n");
        return;
    }
    // 这里user已经检查过不为NULL
    printf("User name: %s\n", user->name);  // 误报：已经检查过NULL
}

// ==================== CWE问题5: S_02_05 使用已释放的内存（真实问题）====================
// 行号: 74
void use_after_free_example() {
    char *data = (char*)malloc(100);
    if (data) {
        strcpy(data, "Test data");
        printf("Data: %s\n", data);
        free(data);
        // 真实问题：使用已释放的内存
        printf("Again: %s\n", data);  // 真实问题：use after free
    }
}

// ==================== CWE问题6: S_02_06 资源泄漏（误报）====================
// 行号: 88
void resource_properly_freed() {
    FILE *fp = fopen("test.txt", "r");
    if (fp == NULL) {
        return;
    }
    char buffer[100];
    fgets(buffer, 100, fp);
    printf("Read: %s\n", buffer);
    fclose(fp);  // 误报：资源已正确释放
}

// ==================== CWE问题7: S_02_07 格式化字符串漏洞（误报）====================
// 行号: 102
void safe_string_format(const char* user_input) {
    // 误报：使用了格式化字符串，但输入是受控的
    char formatted[200];
    snprintf(formatted, sizeof(formatted), "User input: %s", user_input);  // 误报：安全的格式化
    printf("%s\n", formatted);
}

// ==================== CWE问题8: S_02_08 数组越界（误报）====================
// 行号: 112
void bounded_array_access() {
    int numbers[10];
    int index = 5;
    
    // 误报：索引在有效范围内
    if (index >= 0 && index < 10) {
        numbers[index] = 100;  // 误报：索引已验证
        printf("Set numbers[%d] = %d\n", index, numbers[index]);
    }
}

// ==================== CWE问题9: S_02_09 竞态条件（误报）====================
// 行号: 126
// 单线程环境，不存在竞态条件
void check_and_use_file() {
    // 误报：虽然是TOCTOU模式，但在单线程环境中是安全的
    if (access("config.txt", R_OK) == 0) {  // 检查文件
        FILE *fp = fopen("config.txt", "r");  // 打开文件
        if (fp) {
            // 误报：单线程环境下不存在竞态条件
            char buffer[100];
            fgets(buffer, 100, fp);
            fclose(fp);
        }
    }
}

// ==================== CWE问题10: S_02_10 内存泄漏（误报）====================
// 行号: 143
void conditional_memory_cleanup(int should_allocate) {
    char *buffer = NULL;
    
    if (should_allocate) {
        buffer = (char*)malloc(100);
        if (buffer) {
            strcpy(buffer, "Allocated");
            printf("%s\n", buffer);
        }
    }
    
    // 误报：在所有应该释放的路径上都释放了
    if (buffer) {
        free(buffer);  // 误报：内存已正确释放
        buffer = NULL;
    }
}

// 测试主函数
int main() {
    printf("=== CWE Test Cases ===\n");
    
    // 注意：某些测试会导致程序崩溃，这里只是示例
    // process_uninitialized_pointer();  // 会崩溃 - 真实问题
    
    safe_buffer_copy("Short string");  // 误报
    
    // allocate_with_overflow();  // 真实问题
    
    UserInfo test_user = {"TestUser", 1, 1};
    process_with_null_check(&test_user);  // 误报
    
    // use_after_free_example();  // 真实问题
    
    resource_properly_freed();  // 误报
    
    safe_string_format("Test input");  // 误报
    
    bounded_array_access();  // 误报
    
    check_and_use_file();  // 误报
    
    conditional_memory_cleanup(1);  // 误报
    
    printf("=== Tests Complete ===\n");
    return 0;
}

