#include <iostream>
#include <string>

class Calculator {
public:
    int add(int a, int b) {
        return a + b;
    }
    
    int subtract(int a, int b) {
        return a - b;
    }
    
    int multiply(int a, int b) {
        return a * b;
    }
};

class MathOperations {
private:
    Calculator calc;
    
public:
    void perform_operations(int x, int y) {
        int sum = calc.add(x, y);         // 调用Calculator类的add方法
        int diff = calc.subtract(x, y);   // 调用Calculator类的subtract方法
        int product = calc.multiply(x, y); // 调用Calculator类的multiply方法
        
        std::cout << "Sum: " << sum << std::endl;
        std::cout << "Difference: " << diff << std::endl;
        std::cout << "Product: " << product << std::endl;
    }
}; 