// 违反 R-1-3-1: 使用三级指针
int*** create_triple_pointer(void) {
    int*** ptr = (int***)malloc(sizeof(int**));
    *ptr = (int**)malloc(sizeof(int*));
    **ptr = (int*)malloc(sizeof(int));
    ***ptr = 42;
    return ptr;
}

// 违反 R-1-3-2: 函数指针使用未加&
void (*get_function_pointer(void))(void) {
    void (*func)(void) = printf;  // 未使用&
    return func;
}

// 违反 R-1-3-3: 对参数指针进行赋值
void modify_parameter_pointer(int* ptr) {
    int value = 100;
    ptr = &value;  // 对参数指针进行赋值
}

// 违反 R-1-3-4: 返回局部变量地址
int* return_local_variable(void) {
    int local_var = 42;
    return &local_var;  // 返回局部变量地址
}
