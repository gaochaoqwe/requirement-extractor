#include <iostream>
#include <memory>

class Database {
public:
    void connect() {
        std::cout << "Connecting to database..." << std::endl;
    }
    
    void query(const std::string& sql) {
        std::cout << "Executing query: " << sql << std::endl;
    }
    
    void disconnect() {
        std::cout << "Disconnecting from database..." << std::endl;
    }
};

class DatabaseManager {
private:
    std::unique_ptr<Database> db;
    
public:
    DatabaseManager() : db(std::make_unique<Database>()) {}
    
    void perform_database_operations() {
        db->connect();                    // 通过指针调用connect方法
        db->query("SELECT * FROM users"); // 通过指针调用query方法
        db->disconnect();                 // 通过指针调用disconnect方法
    }
}; 