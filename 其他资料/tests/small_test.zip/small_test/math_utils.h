#ifndef MATH_UTILS_H
#define MATH_UTILS_H

int square(int x);
double sqrt_custom(double x);
int factorial(int n);

#endif 