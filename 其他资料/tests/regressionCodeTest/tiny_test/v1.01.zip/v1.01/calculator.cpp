#include "calculator.h"
#include <stdexcept>
#include <cmath>
#include <iomanip>
#include <sstream>

double Calculator::add(double a, double b) {
    double result = a + b;
    addToHistory("Add: " + std::to_string(a) + " + " + std::to_string(b), result);
    return result;
}

double Calculator::subtract(double a, double b) {
    double result = a - b;
    addToHistory("Subtract: " + std::to_string(a) + " - " + std::to_string(b), result);
    return result;
}

double Calculator::multiply(double a, double b) {
    double result = a * b;
    addToHistory("Multiply: " + std::to_string(a) + " * " + std::to_string(b), result);
    return result;
}

double Calculator::divide(double a, double b) {
    if (b == 0) {
        addToHistory("Divide: " + std::to_string(a) + " / " + std::to_string(b) + " (Error)", 0);
        throw std::runtime_error("Division by zero!");
    }
    double result = a / b;
    addToHistory("Divide: " + std::to_string(a) + " / " + std::to_string(b), result);
    return result;
}

double Calculator::power(double base, double exponent) {
    double result = std::pow(base, exponent);
    addToHistory("Power: " + std::to_string(base) + " ^ " + std::to_string(exponent), result);
    return result;
}

void Calculator::setMemory(double value) {
    memory = value;
    addToHistory("Set memory to", value);
}

double Calculator::getMemory() const {
    return memory;
}

void Calculator::clearMemory() {
    memory = 0.0;
    addToHistory("Memory cleared", 0);
}

void Calculator::addToHistory(const std::string& operation, double result) {
    history.push_back({operation, result});
}

void Calculator::clearHistory() {
    history.clear();
}

void Calculator::printHistory() const {
    std::cout << "\nOperation History:";
    std::cout << "\n-----------------";
    for (const auto& entry : history) {
        std::cout << "\n" << entry.operation << " = " << entry.result;
    }
    std::cout << "\n-----------------\n";
}
