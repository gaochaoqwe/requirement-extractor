module lihua();


	CMOS_Capture_RGB565 #(
			.CMOS_FRAME_WAITCNT(5)
		) inst_CMOS_Capture_RGB565 (
			.clk_cmos         (clk_cmos),
			.rst_n            (rst_n),
			.cmos_pclk        (cmos_pclk),
			.cmos_xclk        (cmos_xclk),
			.cmos_vsync       (cmos_vsync),
			.cmos_href        (cmos_href),
			.cmos_data        (cmos_data),
			.cmos_frame_vsync (cmos_frame_vsync),
			.cmos_frame_href  (cmos_frame_href),
			.cmos_frame_data  (cmos_frame_data),
			.cmos_frame_clken (cmos_frame_clken),
			.cmos_fps_rate    (cmos_fps_rate)
		);

	command inst_command
		(
			.CLK       (CLK),
			.RESET_N   (RESET_N),
			.SADDR     (SADDR),
			.NOP       (NOP),
			.READA     (READA),
			.WRITEA    (WRITEA),
			.REFRESH   (REFRESH),
			.PRECHARGE (PRECHARGE),
			.LOAD_MODE (LOAD_MODE),
			.REF_REQ   (REF_REQ),
			.INIT_REQ  (INIT_REQ),
			.PM_STOP   (PM_STOP),
			.PM_DONE   (PM_DONE),
			.REF_ACK   (REF_ACK),
			.CM_ACK    (CM_ACK),
			.OE        (OE),
			.SA        (SA),
			.BA        (BA),
			.CS_N      (CS_N),
			.CKE       (CKE),
			.RAS_N     (RAS_N),
			.CAS_N     (CAS_N),
			.WE_N      (WE_N)
		);
		
			control_interface #(
			.INIT_PER(1),
			.REF_PER(1)
		) inst_control_interface (
			.CLK             (CLK),
			.RESET_N         (RESET_N),
			.CMD             (CMD),
			.ADDR            (ADDR),
			.REF_ACK         (REF_ACK),
			.CM_ACK          (CM_ACK),
			.NOP             (NOP),
			.READA           (READA),
			.WRITEA          (WRITEA),
			.REFRESH         (REFRESH),
			.PRECHARGE       (PRECHARGE),
			.LOAD_MODE       (LOAD_MODE),
			.SADDR           (SADDR),
			.REF_REQ         (REF_REQ),
			.INIT_REQ        (INIT_REQ),
			.CMD_ACK         (CMD_ACK),
			.Sdram_Init_Done (Sdram_Init_Done)
		);
		
		led_input_display #(
			.LED_WIDTH(12)
		) inst_led_input_display (
			.clk       (clk),
			.rst_n     (rst_n),
			.led_en    (led_en),
			.led_value (led_value),
			.led_data  (led_data)
		);
		
			led_breathe_display #(.LED_WIDTH(12)) inst_led_breathe_display (.clk(clk), .rst_n(rst_n), .led_data(led_data));


	lcd_display inst_lcd_display
		(
			.clk      (clk),
			.rst_n    (rst_n),
			.lcd_xpos (lcd_xpos),
			.lcd_ypos (lcd_ypos),
			.lcd_data (lcd_data)
		);
	key_counter_scan #(
			.KEY_WIDTH(5)
		) inst_key_counter_scan (
			.clk       (clk),
			.rst_n     (rst_n),
			.key_data  (key_data),
			.key_flag  (key_flag),
			.key_value (key_value)
		);

	Image_RGB888_YCbCr444 inst_Image_RGB888_YCbCr444
		(
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_frame_clken  (per_frame_clken),
			.per_img_red      (per_img_red),
			.per_img_green    (per_img_green),
			.per_img_blue     (per_img_blue),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_frame_clken (post_frame_clken),
			.post_img_Y       (post_img_Y),
			.post_img_Cb      (post_img_Cb),
			.post_img_Cr      (post_img_Cr)
		);
	i2c_timing_ctrl #(
			.CLK_FREQ(10),
			.I2C_FREQ(10000)
		) inst_i2c_timing_ctrl (
			.clk              (clk),
			.rst_n            (rst_n),
			.i2c_sclk         (i2c_sclk),
			.i2c_sdat         (i2c_sdat),
			.i2c_config_size  (i2c_config_size),
			.i2c_config_index (i2c_config_index),
			.i2c_config_data  (i2c_config_data),
			.i2c_config_done  (i2c_config_done),
			.i2c_rdata        (i2c_rdata)
		);

	I2C_OV7725_YUV422_Config inst_I2C_OV7725_YUV422_Config (.LUT_INDEX(LUT_INDEX), .LUT_DATA(LUT_DATA), .LUT_SIZE(LUT_SIZE));
	I2C_OV7725_RGB565_Config inst_I2C_OV7725_RGB565_Config (.LUT_INDEX(LUT_INDEX), .LUT_DATA(LUT_DATA), .LUT_SIZE(LUT_SIZE));
	I2C_OV5640_RGB565_Config inst_I2C_OV5640_RGB565_Config (.LUT_INDEX(LUT_INDEX), .LUT_DATA(LUT_DATA), .LUT_SIZE(LUT_SIZE));
	write_fifo1 inst_write_fifo1
		(
			.aclr    (aclr),
			.data    (data),
			.rdclk   (rdclk),
			.rdreq   (rdreq),
			.wrclk   (wrclk),
			.wrreq   (wrreq),
			.q       (q),
			.rdusedw (rdusedw)
		);
	VIP_Sobel_Edge_Detector #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_VIP_Sobel_Edge_Detector (
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_img_Gray     (per_img_Gray),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_img_Bit     (post_img_Bit),
			.Sobel_Threshold  (Sobel_Threshold)
		);
	VIP_Matrix_Generate_3X3_8Bit #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_VIP_Matrix_Generate_3X3_8Bit (
			.clk                (clk),
			.rst_n              (rst_n),
			.per_frame_vsync    (per_frame_vsync),
			.per_frame_href     (per_frame_href),
			.per_img_Gray       (per_img_Gray),
			.matrix_frame_vsync (matrix_frame_vsync),
			.matrix_frame_href  (matrix_frame_href),
			.matrix_p11         (matrix_p11),
			.matrix_p12         (matrix_p12),
			.matrix_p13         (matrix_p13),
			.matrix_p21         (matrix_p21),
			.matrix_p22         (matrix_p22),
			.matrix_p23         (matrix_p23),
			.matrix_p31         (matrix_p31),
			.matrix_p32         (matrix_p32),
			.matrix_p33         (matrix_p33)
		);
	VIP_Matrix_Generate_3X3_1Bit #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_VIP_Matrix_Generate_3X3_1Bit (
			.clk                (clk),
			.rst_n              (rst_n),
			.per_frame_vsync    (per_frame_vsync),
			.per_frame_href     (per_frame_href),
			.per_img_Bit        (per_img_Bit),
			.matrix_frame_vsync (matrix_frame_vsync),
			.matrix_frame_href  (matrix_frame_href),
			.matrix_p11         (matrix_p11),
			.matrix_p12         (matrix_p12),
			.matrix_p13         (matrix_p13),
			.matrix_p21         (matrix_p21),
			.matrix_p22         (matrix_p22),
			.matrix_p23         (matrix_p23),
			.matrix_p31         (matrix_p31),
			.matrix_p32         (matrix_p32),
			.matrix_p33         (matrix_p33)
		);
	VIP_Bit_Erosion_Detector #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_VIP_Bit_Erosion_Detector (
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_img_Bit      (per_img_Bit),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_img_Bit     (post_img_Bit)
		);
	VIP_Bit_Dilation_Detector #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_VIP_Bit_Dilation_Detector (
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_frame_clken  (per_frame_clken),
			.per_img_Bit      (per_img_Bit),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_img_Bit     (post_img_Bit)
		);
			system_init_delay #(
			.SYS_DELAY_TOP(1)
		) inst_system_init_delay (
			.clk        (clk),
			.rst_n      (rst_n),
			.delay_done (delay_done)
		);
	SQRT inst_SQRT (.radical(radical), .q(q), .remainder(remainder));
	system_ctrl inst_system_ctrl (.clk(clk), .rst_n(rst_n), .clk_ref(clk_ref), .sys_rst_n(sys_rst_n));
	Sobel_Threshold_Adj inst_Sobel_Threshold_Adj
		(
			.clk             (clk),
			.rst_n           (rst_n),
			.key_flag        (key_flag),
			.key_value       (key_value),
			.Sobel_Grade     (Sobel_Grade),
			.Sobel_Threshold (Sobel_Threshold)
		);
	Sdram_Control_2Port inst_Sdram_Control_2Port
		(
			.REF_CLK           (REF_CLK),
			.OUT_CLK           (OUT_CLK),
			.RESET_N           (RESET_N),
			.WR_DATA           (WR_DATA),
			.WR                (WR),
			.WR_MIN_ADDR       (WR_MIN_ADDR),
			.WR_MAX_ADDR       (WR_MAX_ADDR),
			.WR_LENGTH         (WR_LENGTH),
			.WR_LOAD           (WR_LOAD),
			.WR_CLK            (WR_CLK),
			.RD_DATA           (RD_DATA),
			.RD                (RD),
			.RD_MIN_ADDR       (RD_MIN_ADDR),
			.RD_MAX_ADDR       (RD_MAX_ADDR),
			.RD_LENGTH         (RD_LENGTH),
			.RD_LOAD           (RD_LOAD),
			.RD_CLK            (RD_CLK),
			.SA                (SA),
			.BA                (BA),
			.CS_N              (CS_N),
			.CKE               (CKE),
			.RAS_N             (RAS_N),
			.CAS_N             (CAS_N),
			.WE_N              (WE_N),
			.DQ                (DQ),
			.DQM               (DQM),
			.SDR_CLK           (SDR_CLK),
			.Sdram_Init_Done   (Sdram_Init_Done),
			.Sdram_Read_Valid  (Sdram_Read_Valid),
			.Sdram_PingPong_EN (Sdram_PingPong_EN)
		);

	reset inst_reset (.clk(clk), .rst_n(rst_n));
	read_fifo1 inst_read_fifo1
		(
			.aclr    (aclr),
			.data    (data),
			.rdclk   (rdclk),
			.rdreq   (rdreq),
			.wrclk   (wrclk),
			.wrreq   (wrreq),
			.q       (q),
			.wrusedw (wrusedw)
		);
	mem_test #(
			.MEM_DATA_BITS(1),
			.ADDR_BITS(1),
			.IDLE(1),
			.MEM_READ(1),
			.MEM_WRITE(1),
			.BURST_LEN(1)
		) inst_mem_test (
			.rst                 (rst),
			.mem_clk             (mem_clk),
			.rd_burst_req        (rd_burst_req),
			.wr_burst_req        (wr_burst_req),
			.rd_burst_len        (rd_burst_len),
			.wr_burst_len        (wr_burst_len),
			.rd_burst_addr       (rd_burst_addr),
			.wr_burst_addr       (wr_burst_addr),
			.rd_burst_data_valid (rd_burst_data_valid),
			.wr_burst_data_req   (wr_burst_data_req),
			.rd_burst_data       (rd_burst_data),
			.wr_burst_data       (wr_burst_data),
			.rd_burst_finish     (rd_burst_finish),
			.wr_burst_finish     (wr_burst_finish),
			.error               (error)
		);
	Line_Shift_RAM_8Bit #(
			.RAM_Length(12)
		) inst_Line_Shift_RAM_8Bit (
			.clken    (clken),
			.clock    (clock),
			.shiftin  (shiftin),
			.shiftout (shiftout),
			.taps0x   (taps0x),
			.taps1x   (taps1x)
		);
	Line_Shift_RAM_1Bit #(
			.RAM_Length(12)
		) inst_Line_Shift_RAM_1Bit (
			.clken    (clken),
			.clock    (clock),
			.shiftin  (shiftin),
			.shiftout (shiftout),
			.taps0x   (taps0x),
			.taps1x   (taps1x)
		);
	led_water_display_V0 #(.LED_WIDTH(12)) inst_led_water_display_V0 (.clk(clk), .rst_n(rst_n), .led_data(led_data));
	led_water_display #(.LED_WIDTH(12)) inst_led_water_display (.clk(clk), .rst_n(rst_n), .led_data(led_data));

endmodule 