	
module test_top#(
  //***************************************************************************
  // Traffic Gen related parameters
  //***************************************************************************
  parameter PORT_MODE             = "BI_MODE",
  parameter DATA_MODE             = 4'b0010,
  parameter TST_MEM_INSTR_MODE    = "R_W_INSTR_MODE",
  parameter EYE_TEST              = "FALSE",
                                    // set EYE_TEST = "TRUE" to probe memory
                                    // signals. Traffic Generator will only
                                    // write to one single location and no
                                    // read transactions will be generated.
  parameter DATA_PATTERN          = "DGEN_ALL",
                                     // For small devices, choose one only.
                                     // For large device, choose "DGEN_ALL"
                                     // "DGEN_HAMMER", "DGEN_WALKING1",
                                     // "DGEN_WALKING0","DGEN_ADDR","
                                     // "DGEN_NEIGHBOR","DGEN_PRBS","DGEN_ALL"
  parameter CMD_PATTERN           = "CGEN_ALL",
                                     // "CGEN_PRBS","CGEN_FIXED","CGEN_BRAM",
                                     // "CGEN_SEQUENTIAL", "CGEN_ALL"
  parameter CMD_WDT               = 'h3FF,
  parameter WR_WDT                = 'h1FFF,
  parameter RD_WDT                = 'h3FF,
  parameter SEL_VICTIM_LINE       = 0,
  parameter BEGIN_ADDRESS         = 32'h00000000,
  parameter END_ADDRESS           = 32'h00ffffff,
  parameter PRBS_EADDR_MASK_POS   = 32'hff000000,

  //***************************************************************************
  // The following parameters refer to width of various ports
  //***************************************************************************
  parameter CK_WIDTH              = 1,
                                    // # of CK/CK# outputs to memory.
  parameter nCS_PER_RANK          = 1,
                                    // # of unique CS outputs per rank for phy
  parameter CKE_WIDTH             = 1,
                                    // # of CKE outputs to memory.
  parameter DM_WIDTH              = 4,
                                    // # of DM (data mask)
  parameter ODT_WIDTH             = 1,
                                    // # of ODT outputs to memory.
  parameter BANK_WIDTH            = 3,
                                    // # of memory Bank Address bits.
  parameter COL_WIDTH             = 10,
                                    // # of memory Column Address bits.
  parameter CS_WIDTH              = 1,
                                    // # of unique CS outputs to memory.
  parameter DQ_WIDTH              = 32,
                                    // # of DQ (data)
  parameter DQS_WIDTH             = 4,
  parameter DQS_CNT_WIDTH         = 2,
                                    // = ceil(log2(DQS_WIDTH))
  parameter DRAM_WIDTH            = 8,
                                    // # of DQ per DQS
  parameter ECC                   = "OFF",
  parameter ECC_TEST              = "OFF",
  //parameter nBANK_MACHS           = 4,
  parameter nBANK_MACHS           = 4,
  parameter RANKS                 = 1,
                                    // # of Ranks.
  parameter ROW_WIDTH             = 14,
                                    // # of memory Row Address bits.
  parameter ADDR_WIDTH            = 28,
                                    // # = RANK_WIDTH + BANK_WIDTH
                                    //     + ROW_WIDTH + COL_WIDTH;
                                    // Chip Select is always tied to low for
                                    // single rank devices
  //***************************************************************************
  // The following parameters are mode register settings
  //***************************************************************************
  parameter BURST_MODE            = "8",
                                    // DDR3 SDRAM:
                                    // Burst Length (Mode Register 0).
                                    // # = "8", "4", "OTF".
                                    // DDR2 SDRAM:
                                    // Burst Length (Mode Register).
                                    // # = "8", "4".
  //***************************************************************************
  // The following parameters are multiplier and divisor factors for PLLE2.
  // Based on the selected design frequency these parameters vary.
  //***************************************************************************
  parameter CLKIN_PERIOD          = 5000,
                                    // Input Clock Period
  parameter CLKFBOUT_MULT         = 4,
                                    // write PLL VCO multiplier
  parameter DIVCLK_DIVIDE         = 1,
                                    // write PLL VCO divisor
  parameter CLKOUT0_PHASE         = 0.0,
                                    // Phase for PLL output clock (CLKOUT0)
  parameter CLKOUT0_DIVIDE        = 1,
                                    // VCO output divisor for PLL output clock (CLKOUT0)
  parameter CLKOUT1_DIVIDE        = 2,
                                    // VCO output divisor for PLL output clock (CLKOUT1)
  parameter CLKOUT2_DIVIDE        = 32,
                                    // VCO output divisor for PLL output clock (CLKOUT2)
  parameter CLKOUT3_DIVIDE        = 8,
                                    // VCO output divisor for PLL output clock (CLKOUT3)
  parameter MMCM_VCO              = 800,
                                    // Max Freq (MHz) of MMCM VCO
  parameter MMCM_MULT_F           = 8,
                                    // write MMCM VCO multiplier
  parameter MMCM_DIVCLK_DIVIDE    = 1,
                                    // write MMCM VCO divisor
  //***************************************************************************
  // Simulation parameters
  //***************************************************************************
  parameter SIMULATION            = "FALSE",
                                    // Should be TRUE during design simulations and
                                    // FALSE during implementations
  //***************************************************************************
  // IODELAY and PHY related parameters
  //***************************************************************************
  parameter TCQ                   = 100,
  
  parameter DRAM_TYPE             = "DDR3",
  //***************************************************************************
  // System clock frequency parameters
  //***************************************************************************
  parameter nCK_PER_CLK           = 4,
                                    // # of memory CKs per fabric CLK
  //***************************************************************************
  // Debug parameters
  //***************************************************************************
  parameter DEBUG_PORT            = "OFF",
                                    // # = "ON" Enable debug signals/controls.
                                    //   = "OFF" Disable debug signals/controls.
  parameter RST_ACT_LOW           = 0
                                    // =1 for active low reset,
                                    // =0 for active high.
  )
 (
  // Inouts
  inout [31:0]                 ddr3_dq,
  inout [3:0]                  ddr3_dqs_n,
  inout [3:0]                  ddr3_dqs_p,
  // Outputs
  output [13:0]                ddr3_addr,
  output [2:0]                 ddr3_ba,
  output                       ddr3_ras_n,
  output                       ddr3_cas_n,
  output                       ddr3_we_n,
  output                       ddr3_reset_n,
  output [0:0]                 ddr3_ck_p,
  output [0:0]                 ddr3_ck_n,
  output [0:0]                 ddr3_cke,
  output [0:0]                 ddr3_cs_n,
  output [3:0]                 ddr3_dm,
  output [0:0]                 ddr3_odt,
  
  output		               cmos_sclk_o,	//cmos i2c clock
  inout                        cmos_sdat_io,    //cmos i2c data
  input                        cmos_vsync_i,    //cmos vsync
  input                        cmos_href_i,    //cmos hsync refrence
  input                        cmos_pclk_i,    //cmos pxiel clock
  output                       cmos_xclk_o,    //cmos externl clock
  input[7:0]                   cmos_data_i,    //cmos data
  	//user interface
  input        [1:0]    key_data,	
//----------------------------- VGA/HDMI hardware interface ----------------------------/
output                         HDMI1_CLK_P, 
output                         HDMI1_CLK_N, 
output                         HDMI1_D2_P,  
output                         HDMI1_D2_N,  
output                         HDMI1_D1_P,  
output                         HDMI1_D1_N,  
output                         HDMI1_D0_P,  
output                         HDMI1_D0_N,  

output                         init_calib_complete,
input                          clk50m_i,
input                          rst_key
);	
		Video_Image_Processor1 #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_Video_Image_Processor1 (
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_img_RAW      (per_img_RAW),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_img_Gray    (post_img_Gray),
			.Sobel_Threshold  (Sobel_Threshold)
		);

	
	CMOS_VIP_HDL_Demo inst_CMOS_VIP_HDL_Demo
	(
		.clk          (clk),
		.rst_n        (rst_n),
		.sdram_clk    (sdram_clk),
		.sdram_cke    (sdram_cke),
		.sdram_cs_n   (sdram_cs_n),
		.sdram_we_n   (sdram_we_n),
		.sdram_cas_n  (sdram_cas_n),
		.sdram_ras_n  (sdram_ras_n),
		.sdram_ba     (sdram_ba),
		.sdram_addr   (sdram_addr),
		.sdram_data   (sdram_data),
		.lcd_dclk     (lcd_dclk),
		.lcd_hs       (lcd_hs),
		.lcd_vs       (lcd_vs),
		.lcd_de       (lcd_de),
		.lcd_red      (lcd_red),
		.lcd_green    (lcd_green),
		.lcd_blue     (lcd_blue),
		.cmos_sclk    (cmos_sclk),
		.cmos_sdat    (cmos_sdat),
		.cmos_pclk    (cmos_pclk),
		.cmos_xclk    (cmos_xclk),
		.cmos_vsync   (cmos_vsync),
		.cmos_href    (cmos_href),
		.cmos_data    (cmos_data),
		.cmos_ctl0    (cmos_ctl0),
		.cmos_ctl1    (cmos_ctl1),
		.cmos_ctl2    (cmos_ctl2),
		.key_data     (key_data),
		.led595_dout  (led595_dout),
		.led595_clk   (led595_clk),
		.led595_latch (led595_latch)
	);
	Video_Image_Processor #(
			.IMG_HDISP(640),
			.IMG_VDISP(480)
		) inst_Video_Image_Processor (
			.clk              (clk),
			.rst_n            (rst_n),
			.per_frame_vsync  (per_frame_vsync),
			.per_frame_href   (per_frame_href),
			.per_img_RAW      (per_img_RAW),
			.post_frame_vsync (post_frame_vsync),
			.post_frame_href  (post_frame_href),
			.post_img_Gray    (post_img_Gray),
			.Sobel_Threshold  (Sobel_Threshold)
		);


		
		OV5640_TOP #(
			.PORT_MODE(PORT_MODE),
			.DATA_MODE(DATA_MODE),
			.TST_MEM_INSTR_MODE(TST_MEM_INSTR_MODE),
			.EYE_TEST(EYE_TEST),
			.DATA_PATTERN(DATA_PATTERN),
			.CMD_PATTERN(CMD_PATTERN),
			.CMD_WDT(CMD_WDT),
			.WR_WDT(WR_WDT),
			.RD_WDT(RD_WDT),
			.SEL_VICTIM_LINE(SEL_VICTIM_LINE),
			.BEGIN_ADDRESS(BEGIN_ADDRESS),
			.END_ADDRESS(END_ADDRESS),
			.PRBS_EADDR_MASK_POS(PRBS_EADDR_MASK_POS),
			.CK_WIDTH(CK_WIDTH),
			.nCS_PER_RANK(nCS_PER_RANK),
			.CKE_WIDTH(CKE_WIDTH),
			.DM_WIDTH(DM_WIDTH),
			.ODT_WIDTH(ODT_WIDTH),
			.BANK_WIDTH(BANK_WIDTH),
			.COL_WIDTH(COL_WIDTH),
			.CS_WIDTH(CS_WIDTH),
			.DQ_WIDTH(DQ_WIDTH),
			.DQS_WIDTH(DQS_WIDTH),
			.DQS_CNT_WIDTH(DQS_CNT_WIDTH),
			.DRAM_WIDTH(DRAM_WIDTH),
			.ECC(ECC),
			.ECC_TEST(ECC_TEST),
			.nBANK_MACHS(nBANK_MACHS),
			.RANKS(RANKS),
			.ROW_WIDTH(ROW_WIDTH),
			.ADDR_WIDTH(ADDR_WIDTH),
			.BURST_MODE(BURST_MODE),
			.CLKIN_PERIOD(CLKIN_PERIOD),
			.CLKFBOUT_MULT(CLKFBOUT_MULT),
			.DIVCLK_DIVIDE(DIVCLK_DIVIDE),
			.CLKOUT0_PHASE(CLKOUT0_PHASE),
			.CLKOUT0_DIVIDE(CLKOUT0_DIVIDE),
			.CLKOUT1_DIVIDE(CLKOUT1_DIVIDE),
			.CLKOUT2_DIVIDE(CLKOUT2_DIVIDE),
			.CLKOUT3_DIVIDE(CLKOUT3_DIVIDE),
			.MMCM_VCO(MMCM_VCO),
			.MMCM_MULT_F(MMCM_MULT_F),
			.MMCM_DIVCLK_DIVIDE(MMCM_DIVCLK_DIVIDE),
			.SIMULATION(SIMULATION),
			.TCQ(TCQ),
			.DRAM_TYPE(DRAM_TYPE),
			.nCK_PER_CLK(nCK_PER_CLK),
			.DEBUG_PORT(DEBUG_PORT),
			.RST_ACT_LOW(RST_ACT_LOW)
		) inst_OV5640_TOP (
			.ddr3_dq             (ddr3_dq),
			.ddr3_dqs_n          (ddr3_dqs_n),
			.ddr3_dqs_p          (ddr3_dqs_p),
			.ddr3_addr           (ddr3_addr),
			.ddr3_ba             (ddr3_ba),
			.ddr3_ras_n          (ddr3_ras_n),
			.ddr3_cas_n          (ddr3_cas_n),
			.ddr3_we_n           (ddr3_we_n),
			.ddr3_reset_n        (ddr3_reset_n),
			.ddr3_ck_p           (ddr3_ck_p),
			.ddr3_ck_n           (ddr3_ck_n),
			.ddr3_cke            (ddr3_cke),
			.ddr3_cs_n           (ddr3_cs_n),
			.ddr3_dm             (ddr3_dm),
			.ddr3_odt            (ddr3_odt),
			.cmos_sclk_o         (cmos_sclk_o),
			.cmos_sdat_io        (cmos_sdat_io),
			.cmos_vsync_i        (cmos_vsync_i),
			.cmos_href_i         (cmos_href_i),
			.cmos_pclk_i         (cmos_pclk_i),
			.cmos_xclk_o         (cmos_xclk_o),
			.cmos_data_i         (cmos_data_i),
			.key_data            (key_data),
			.HDMI1_CLK_P         (HDMI1_CLK_P),
			.HDMI1_CLK_N         (HDMI1_CLK_N),
			.HDMI1_D2_P          (HDMI1_D2_P),
			.HDMI1_D2_N          (HDMI1_D2_N),
			.HDMI1_D1_P          (HDMI1_D1_P),
			.HDMI1_D1_N          (HDMI1_D1_N),
			.HDMI1_D0_P          (HDMI1_D0_P),
			.HDMI1_D0_N          (HDMI1_D0_N),
			.init_calib_complete (init_calib_complete),
			.clk50m_i            (clk50m_i),
			.rst_key             (rst_key)
		);

	
	
	
	top inst_top
		(
			.hdmi_scl       (hdmi_scl),
			.hdmi_sda       (hdmi_sda),
			.hdmi_nreset    (hdmi_nreset),
			.hdmi_in_nreset (hdmi_in_nreset),
			.vin_clk        (vin_clk),
			.vin_hs         (vin_hs),
			.vin_vs         (vin_vs),
			.vin_de         (vin_de),
			.vin_data       (vin_data),
			.vout_clk       (vout_clk),
			.vout_hs        (vout_hs),
			.vout_vs        (vout_vs),
			.vout_de        (vout_de),
			.vout_data      (vout_data),
			.ddr3_dq        (ddr3_dq),
			.ddr3_dqs_n     (ddr3_dqs_n),
			.ddr3_dqs_p     (ddr3_dqs_p),
			.ddr3_addr      (ddr3_addr),
			.ddr3_ba        (ddr3_ba),
			.ddr3_ras_n     (ddr3_ras_n),
			.ddr3_cas_n     (ddr3_cas_n),
			.ddr3_we_n      (ddr3_we_n),
			.ddr3_reset_n   (ddr3_reset_n),
			.ddr3_ck_p      (ddr3_ck_p),
			.ddr3_ck_n      (ddr3_ck_n),
			.ddr3_cke       (ddr3_cke),
			.ddr3_cs_n      (ddr3_cs_n),
			.ddr3_dm        (ddr3_dm),
			.ddr3_odt       (ddr3_odt),
			.sys_clk_p      (sys_clk_p),
			.sys_clk_n      (sys_clk_n),
			.led            (led),
			.sys_rst        (sys_rst)
		);
	lihua inst();
		CH6_FIFO inst_CH6_FIFO
		(
			.rst           (rst),
			.wr_clk        (wr_clk),
			.rd_clk        (rd_clk),
			.din           (din),
			.wr_en         (wr_en),
			.rd_en         (rd_en),
			.dout          (dout),
			.full          (full),
			.empty         (empty),
			.rd_data_count (rd_data_count),
			.wr_data_count (wr_data_count)
		);
	CH0_FIFO inst_CH0_FIFO
		(
			.rst           (rst),
			.wr_clk        (wr_clk),
			.rd_clk        (rd_clk),
			.din           (din),
			.wr_en         (wr_en),
			.rd_en         (rd_en),
			.dout          (dout),
			.full          (full),
			.empty         (empty),
			.rd_data_count (rd_data_count)
		);

endmodule